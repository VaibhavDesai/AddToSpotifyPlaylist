# SpotifyPlaylist
This is a open source project that lets you search and add songs to Spotify playlist directly from an extension. This also allows to capture songs right from the youtube and it to Spotify playlist
