var authorize_url = 'https://accounts.spotify.com/authorize';
var redirect_uri = "https://vaibhavdesai.github.io/";
var scope = "playlist-read-private playlist-modify-public playlist-modify-private user-read-email";
var search_url = 'https://api.spotify.com/v1/search';
var playlist_url = 'https://api.spotify.com/v1/me/playlists';
var user_url = 'https://api.spotify.com/v1/me';
var token_url = 'https://accounts.spotify.com/api/token';
